<?php /* Template Name: Successful_registration_VForm */ ?>

<?php get_header(); ?>
<main style="
">
<div style="
    display: flex;
    flex-direction: column;
    align-items: center;
" >
<svg xmlns="http://www.w3.org/2000/svg" width="62" height="62" viewBox="0 0 62 62" fill="#00CB14;">
<circle cx="31" cy="31" r="31" fill="#00CB14"/>
<path d="M35 2L11 26L2 17" stroke="white" stroke-width="4"/>

</svg>
    <h3 style="
    
    color: #009F10;
    text-align: center;
    font-family: IRANSansX;
    font-size: 24px;
    font-style: normal;
    font-weight: 900;
    line-height: normal;
    ">درخواست ویزای شما با موفقیت ثبت شد</h3>
    <p style="
    color: #000;
    margin-top: 1.8rem;
text-align: center;
font-family: IRANSansX;
font-size: 15px;
font-style: normal;
font-weight: 400;
line-height: normal;
    ">به زودی برای هماهنگی با شما تماس گرفته خواهد شد.
</p>
<p style="
color: #000;
margin-top: 1rem;
text-align: center;
font-family: IRANSansX;
font-size: 15px;
font-style: normal;
font-weight: 400;
line-height: normal;"
>
تایید ویزا منوط به تصمیم سفارت کشور مقصد است و فلای آس هیچ مسئولیتی در قبال رد ویزا ندارد. 
در صورتنیاز به مدارک اضافی، پردازش ویزا می‌تواند تا ۱۰ روز کاری به تاخیر بیفتد.
</p>
</div>
</main>
<?php get_footer(); ?>
