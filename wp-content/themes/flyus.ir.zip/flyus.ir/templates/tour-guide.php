<?php /* Template Name: Tour Guide*/ ?>
<?php get_header(); ?>
<!-- body  -->
 <main class="main">
        <!-- search  -->
        <?php get_template_part('template-parts/tour-guide/search') ?>
        <!-- iran  -->
        <?php get_template_part('template-parts/tour-guide/iran') ?>
        <!-- global  -->
        <?php get_template_part('template-parts/tour-guide/global') ?>
</main>
<?php get_footer(); ?>