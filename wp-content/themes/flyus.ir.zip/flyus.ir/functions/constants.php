<?php 
define("THEME_DIR", get_template_directory());
define("THEME_DIR_URI", get_template_directory_uri());
define("THEME_STYLES", THEME_DIR_URI . "/assets/css");
define("THEME_JS", THEME_DIR_URI . "/assets/js");
define("THEME_IMAGE", THEME_DIR_URI . "/assets/img");
define("THEME_VIDEO", THEME_DIR_URI . "/assets/video");
define("THEME_AUDIOS", THEME_DIR_URI . "/assets/audios");
define("THEME_INCLUDES", THEME_DIR . "/includes");
define("THEME_FUNCTION", THEME_DIR . "/functions");
define("THEME_POSTTYPE", THEME_DIR . "/functions/post-types");
define("VERSION", wp_get_theme()->get('Version'));

define('INSURANCE_USER_NAME','WS@EadeaalPavaz.NoyanCore');
define('INSURANCE_PASSWORD','E!d@.p@0458');
//define('INSURANCE_URL','https://samanws.travis.ir/travisservice.asmx?WSDL');
define('INSURANCE_URL','http://193.35.62.85/Apps/NoyanCoreWS_SandBox/travisservice.asmx?WSDL');
