<?php
include THEME_POSTTYPE . '/tours.php';
include THEME_POSTTYPE . '/gallery.php';
include THEME_POSTTYPE . '/visa.php';
include THEME_POSTTYPE .'/form.php';
include THEME_POSTTYPE . '/trip.php';
include THEME_POSTTYPE . '/best-food.php';
include THEME_POSTTYPE . '/best-hotel.php';
include THEME_POSTTYPE . '/best-shopping.php';
include THEME_POSTTYPE . '/best-restaurant.php';
include THEME_POSTTYPE . '/best-recreational-place.php';
