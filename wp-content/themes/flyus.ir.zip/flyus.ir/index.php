<?php get_header(); ?>
    <!-- body  -->
    <main class="mian">
      <!-- introduce  -->
      <?php get_template_part('template-parts/index/intro') ?>
      <!-- flights  -->

      <!-- services  -->
      <?php get_template_part('template-parts/index/services') ?>
      <!-- why us  -->
      <?php get_template_part('template-parts/index/why-us') ?>
      <!-- boxes  -->
      <?php get_template_part('template-parts/index/boxes') ?>
      <!-- tour  -->
      <?php get_template_part('template-parts/index/tour') ?>
      <!-- Advantages -->
      <?php get_template_part('template-parts/index/advantages') ?>
      <!-- introduce  -->
      <?php get_template_part('template-parts/index/introduce') ?>
      <!-- blog  -->
      <?php get_template_part('template-parts/index/blog') ?>
      <!-- content  -->
      <?php get_template_part('template-parts/index/content') ?>
      <!-- FAQ -->
      <?php get_template_part('template-parts/index/faq') ?>
    </main>
<?php get_footer(); ?>
<?php 'template-parts/index/flights' ?>