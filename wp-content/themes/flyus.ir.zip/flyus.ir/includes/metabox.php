<?php
require_once THEME_INCLUDES . '/metaboxes/visa.php';
require_once THEME_INCLUDES . '/metaboxes/tour.php';
require_once THEME_INCLUDES . '/metaboxes/trip.php';
require_once THEME_INCLUDES . '/metaboxes/gallery.php';
require_once THEME_INCLUDES . '/metaboxes/post.php';

