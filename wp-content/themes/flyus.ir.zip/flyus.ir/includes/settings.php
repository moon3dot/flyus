<?php
require_once THEME_INCLUDES . '/theme-settings/home.php';
require_once THEME_INCLUDES . '/theme-settings/insurance.php';
require_once THEME_INCLUDES . '/theme-settings/visa.php';
require_once THEME_INCLUDES . '/theme-settings/tour.php';
require_once THEME_INCLUDES . '/theme-settings/footer.php';
require_once THEME_INCLUDES . '/theme-settings/header.php';


